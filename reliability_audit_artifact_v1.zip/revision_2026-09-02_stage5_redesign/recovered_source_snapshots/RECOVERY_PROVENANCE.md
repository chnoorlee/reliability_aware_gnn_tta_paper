# Exact Source Recovery Provenance

Date: 2026-09-02

Scope: only byte-exact source files whose SHA-256 matches a frozen artifact
binding are retained in this directory. No approximate reconstruction is
included.

Boundary: this is mechanical source-byte recovery and hash verification. It
does not constitute reproduction of the Python/package environment, runtime
execution, model state, datasets, hardware, or reported experimental results.

## Recovered files

| Intended use | Relative path | Observed SHA-256 | Recovery method |
|---|---|---|---|
| Held-out endpoint and controller experiments | `heldout_controller/adaptation.py` | `bc904bd20bf91a3c79957db14a8a785a2695090cb73a72c2f9de59c0af79b37f` | Reverse-applied successful JSONL patch events to the then-current file and retained the first exact target state. |
| Held-out endpoint and controller experiments | `heldout_controller/stress_surface.py` | `050c4183b723141755872dc96c690d6893e9ff93bad2b886e5e2b48f26bd96bf` | Copied exact bytes from the frozen Stage-5 source snapshot after an independent hash check. |
| Scope smoke and matched held-out replay | `scope_replay/stress_surface.py` | `b196ea35fc2a14ea861e61ae13d8a7b69161ed72ddfa1f1770cb27221f96fc70` | Applied the two successful scope updates to the verified `050c...` base, then restored UTF-8/no-BOM/LF bytes. |
| Scope smoke and matched held-out replay | `scope_replay/proxy_scope_audit.py` | `997d3db595b1be13f38413c1994dde7097a59ca39ce7f653ba96ba4696aea948` | Replayed the successful add/update JSONL events in order, then restored UTF-8/no-BOM/LF bytes. |

## Frozen artifact bindings

- `revision_2026-08-19/stage4_fresh_full/heldout_endpoint_final_current/results.json`
  has SHA-256 `aa2a4cf290b03d279f8fb081ba268dff67bd490fb1943d8f8546dcbbe11b9ca4`
  and binds `stress_surface.py` to `050c...` and `adaptation.py` to `bc904...`
  in `code_sha256` (lines 83-84).
- `revision_2026-08-19/stage4_fresh_full/controller_audit_final_current_v3/results.json`
  has SHA-256 `ee68c88348446c6b544681847752fbf7d28839c92df08751009ba46b6b29cfd6`
  and independently binds the same two source hashes (lines 83-84).
- `revision_2026-09-02_stage5_redesign/scope_smoke_v2/results.json`
  has SHA-256 `2b4e4d928e6d3e8d104b083abe65e41257d07d91e0c708ea27c091ea438c4e9a`
  and binds scope `stress_surface.py` to `b196...` and
  `proxy_scope_audit.py` to `997d...` (lines 67 and 72).
- `revision_2026-09-02_stage5_redesign/scope_matched_heldout_v2/results.json`
  has SHA-256 `6561cfd7427b7a7ce9a8822df1e5af5e1cd8399f5e8e318fd185845f03f28942`
  and independently binds the same scope hashes (lines 94 and 99).

## Session and event provenance

Session aliases:

The original local session logs are not distributed. Their filenames, retained
only to make the event references below unambiguous, are:

- `S1`: `rollout-2026-09-02T12-05-11-01a0604a-d29f-70b0-aede-0300473751b4.jsonl`
- `S2`: `rollout-2026-09-02T12-30-22-01a06061-e284-7dd1-8b79-c62f9d7aa528.jsonl`
- `SH`: `rollout-2026-09-02T21-17-15-01a06244-3fbd-74d1-94ff-f9ba524d9b01.jsonl`
- `R`: `rollout-2026-08-18T22-41-31-01a01552-0471-7993-924c-1b74259d7177.jsonl`

### `heldout_controller/adaptation.py`

The exact file was recovered mechanically by starting from the then-current
`code_torch/adaptation.py` and reverse-applying the applicable successful
`patch_apply_end` updates in descending order:

1. `SH:4157`, call ID `exec-60694825-27e3-470b-99d3-0c2f4a8f74a1`.
2. `SH:4068`, call ID `exec-7f3c2bc3-afa3-4265-9efd-4df46387e368`.

The second reversal produced the target hash `bc904...`. The recovery command
and its `FOUND target=adaptation.py line=4068` output are recorded at
`R:11025-11026`, call ID `call_LdemwOZt4rUSPfzXsnFMNkqP`. The resulting bytes
were copied only after a fresh SHA-256 check.

### `heldout_controller/stress_surface.py`

The exact bytes were copied from the frozen
`revision_2026-09-02_stage5_redesign/source_snapshot/code_torch/stress_surface.py`
after an independent `Get-FileHash` check returned `050c...`. The source is
independently bound by both Stage-4 JSON artifacts listed above. A replay of
only the available early add/update patch events did not reproduce this byte
state, so that incomplete event chain was not used and is not claimed as
provenance.

### `scope_replay/stress_surface.py`

Starting from the verified `050c...` source snapshot, the following successful
updates were applied in order:

1. `S1:4073`, call ID `exec-ccb66538-f28b-4497-96c0-8eaf248fcdeb`.
2. `S2:4157`, call ID `exec-60694825-27e3-470b-99d3-0c2f4a8f74a1`.

The raw Windows-line-ending state hashed to
`7b166af10052a0555f5f758bbd3d5e675e6e986dee12741c536ab3c820f11370`.
Re-encoding as UTF-8 without BOM with LF line endings produced the exact target
`b196...`.

### `scope_replay/proxy_scope_audit.py`

The file was created and updated from successful JSONL events in this order:

1. `S1:4064`, add, call ID `exec-8b6f9fa2-8de8-4366-b165-4b002a5cb9b4`.
2. `S1:4080`, update, call ID `exec-3a9f3847-9912-4404-a189-6e85c279597f`.
3. `S1:4086`, update, call ID `exec-fd936984-35a9-448d-a87e-8efdc7ee6b77`.
4. `S2:4126`, update, call ID `exec-b14cc83d-7386-40f1-904f-fbcdf8a5c1e3`.
5. `S2:4157`, update, call ID `exec-60694825-27e3-470b-99d3-0c2f4a8f74a1`.

The raw Windows-line-ending state hashed to
`6c56f0ceb82b8d63244456a81739ddc773d7b3ddf1d44752435254a6961f2d60`.
Re-encoding as UTF-8 without BOM with LF line endings produced the exact target
`997d...`.

## Final verification

Verification command:

```powershell
Get-ChildItem -LiteralPath .\heldout_controller,.\scope_replay -File |
  Get-FileHash -Algorithm SHA256
```

The observed hashes are the four full SHA-256 values in the recovered-files
table. All four matched after final persistence. The directory allowlist is
exactly these four Python files plus this provenance report.
